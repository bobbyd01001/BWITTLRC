from setuptools import setup
import os
os.system('pip3 install -r requirements.txt')

__project__ = "TLRC App"
__version__ = "0.0.1"
__description__ = "Tracking-Locate-Reporting-Calculate"
__packages__ = ["tlrc"]
__author__ = "JC Beasley"
__license__ = ''
__url__ = 'http://www.example.com'
__author_email__ = "beaswork@gmail.com"
__requires__ = ["guizero", 'pygal', 'pandas', 'folium', 'webbrowser', 'time', 'os', 'math', 'branca',
                'geoip']

setup(
    name=__project__,
    version=__version__,
    description=__description__,
    packages=__packages__,
    author=__author__,
    license=__license__,
    url=__url__,
    author_email=__author_email__,
    requires=__requires__,
)
