
"""
Copyright 2020 Beawit Consulting LLC

Permission is hereby granted, free of charge,
to any person obtaining a copy of this software
and associated documentation files (the "Software"),
to deal in the Software without restriction, including
without limitation the rights to use, copy, modify, merge,
publish, distribute, sublicense, and/or sell copies of the Software,
and to permit persons to whom the Software is furnished
to do so, subject to the following conditions:

The above copyright notice and this permission notice shall
be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,
TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

Created by JC Beasley
for questions contact beaswork@gmail.com
this script takes input from use and creates csv of recorded user data and then
gives you weather forecast of local city and also will calculate cost of travel to project
destination. Then prints pie and bar chart of results"""

# Imports -------------------------------------------------------------------------------------------------------------
import os
import time
import pygal
import pandas as pd
from guizero import App, Window, PushButton, Text, TextBox, Picture, Box, Combo
from math import radians, sin, cos, acos
from geopy.geocoders import Nominatim
import folium
from pygal.style import Style
import webbrowser
from folium import plugins
from branca.element import Figure

# Variables -----------------------------------------------------------------------------------------------------------
timestamp = time.asctime(time.localtime(time.time()))

# Yearly Variables
year_2019_total = 0
year_2020_total = 0
year_2021_total = 0

# paths to log files and recorded data

contractor_log = 'App_Data/2020/tlrc_2020_performance.csv'
mileage_compensator = open("App_Data/Mileage/mileage_compensator.txt", "w")
art_logo = 'App_Data/app_image/tlrc_app_art.gif'
bwit_logo = 'App_Data/app_image/TLCR_Project_Tracker_small.gif'
html_file = 'App_Data/Visual_Maps/Web_Browser/ip_map.html'

# Generate yearly performance charts
year_2019_log_path = 'App_Data/2019/tlrc_2019_performance.csv'
year_2020_log_path = 'App_Data/2020/tlrc_2020_performance.csv'
data_crawl = pd.read_csv(contractor_log)
count_row = data_crawl.shape[0]

year_2019_data_crawl = pd.read_csv(year_2019_log_path)
year_2019_count_row = year_2019_data_crawl.shape[0]

year_2020_data_crawl = pd.read_csv(year_2020_log_path)
year_2020_count_row = year_2020_data_crawl.shape[0]

pd.set_option("display.max.columns", None)
# creates master dataframe
data_frame = pd.DataFrame(data_crawl, columns=["DATE", "PLATFORM", "ADDRESS", "CITY", "STATE", "ZIP"])
city_count = (data_frame.CITY.value_counts(sort=True))  # Counts total value of City Column
state_count = (data_frame.STATE.value_counts(sort=True))  # Counts total value of State Column
platform_count = (data_frame.PLATFORM.value_counts(sort=True))   # Counts total value of Vendor Column
cc_frame = pd.DataFrame(city_count)  # Creates new dataframe for city count
ss_frame = pd.DataFrame(state_count)  # Creates new dataframe for state count
pp_frame = pd.DataFrame(platform_count)  # Creates new dataframe for vendor count

january = data_frame[data_frame['DATE'].str.contains('Jan')]
february = data_frame[data_frame['DATE'].str.contains('Feb')]
march = data_frame[data_frame['DATE'].str.contains('Mar')]
april = data_frame[data_frame['DATE'].str.contains('Apr')]
may = data_frame[data_frame['DATE'].str.contains('May')]
june = data_frame[data_frame['DATE'].str.contains('Jun')]
july = data_frame[data_frame['DATE'].str.contains('Jul')]
august = data_frame[data_frame['DATE'].str.contains('Aug')]
september = data_frame[data_frame['DATE'].str.contains('Sep')]
october = data_frame[data_frame['DATE'].str.contains('Oct')]
november = data_frame[data_frame['DATE'].str.contains('Nov')]
december = data_frame[data_frame['DATE'].str.contains('Dec')]


# Functions -----------------------------------------------------------------------------------------------------------
def yearly_performance():
    yearly_chart = pygal.Bar(explicit_size=50)
    yearly_chart.title = 'PROJECT PERFORMANCE BY YEAR'
    yearly_chart.x_title = 'Yearly Totals'
    yearly_chart._y_title = 'Total Projects'
    yearly_chart.x_labels = '2019', '2020', '2021', '2022', '2023', '2024', '2025', '2026', '2027', '2028', '2029', '2030'
    yearly_chart.add('2019', [year_2019_count_row]),
    yearly_chart.add('2020', [None, year_2020_count_row])
    yearly_chart.render_in_browser()


def city_performance():   # Function to create Bar Chart for city performance
    # Create custom styles
    custom_style = Style(colors=('#DB8274', '#338391', '#D3A3D9', '#900C3F', '#D4D068'))
    city_chart = pygal.HorizontalBar(explicit_size=50)
    city_chart.y_title = 'PROJECT CITY'
    city_chart.x_title = 'PROJECTS COMPLETED'
    city_chart.title = "Project Performance by City"
    for (a, b) in cc_frame.iterrows():
        city_chart.add(a, b)
    city_chart.render_in_browser()


# Monthly Performance Log Function
def monthly_performance():
    monthly_chart = pygal.Bar(explicit_size=50)
    monthly_chart.title = 'MONTHLY PROJECT PERFORMANCE'
    monthly_chart.x_title = '2020'
    monthly_chart.y_title = 'PROJECTS COMPLETED'
    monthly_chart.x_labels = 'JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN', 'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC'
    monthly_chart.add('JANUARY', [january.count()[0]])
    monthly_chart.add('FEBRUARY', [None, february.count()[0]])
    monthly_chart.add('MARCH', [None, None, march.count()[0]])
    monthly_chart.add('APRIL', [None, None, None, april.count()[0]])
    monthly_chart.add('MAY', [None, None, None, None, may.count()[0]])
    monthly_chart.add('JUNE', [None, None, None, None, None, june.count()[0]])
    monthly_chart.add('JULY', [None, None, None, None, None, None, july.count()[0]])
    monthly_chart.add('AUGUST', [None, None, None, None, None, None, None, august.count()[0]])
    monthly_chart.add('SEPTEMBER', [None, None, None, None, None, None, None, None, september.count()[0]])
    monthly_chart.add('OCTOBER', [None, None, None, None, None, None, None, None, None, october.count()[0]])
    monthly_chart.add('NOVEMBER', [None, None, None, None, None, None, None, None, None, None, november.count()[0]])
    monthly_chart.add('DECEMBER', [None, None, None, None, None, None, None, None, None, None, None, december.count()[0]])
    monthly_chart.render_in_browser()


# Vendor Performance Log Function
def vendor_performance():   # Function to create Bar Chart for project performance
    # Create custom styles
    custom_style = Style(colors=('#DB8274', '#338391', '#D3A3D9', '#900C3F', '#D4D068'))
    performance_chart = pygal.Bar(explicit_size=50, style=custom_style)
    performance_chart.x_title = 'VENDORS'
    performance_chart.y_title = 'PROJECTS COMPLETED'
    performance_chart.title = "Project Performance by Vendor"
    for (e, f) in pp_frame.iterrows():
        performance_chart.add(e, round(f))
    performance_chart.render_in_browser()


# State Performance Log Function
def state_performance():  # Function to create Pie Chart for state performance
    # Create custom styles
    custom_style = Style(colors=('#DB8274', '#338391', '#D3A3D9', '#900C3F', '#D4D068'))
    state_chart = pygal.Pie(explicit_size=50)
    state_chart.title = "Project Performance by State"
    for (c, d) in ss_frame.iterrows():
        state_chart.add(c, d,)
    state_chart.render_in_browser()


# Function that opens Window to update Performance Logs
def open_window_1():
    # 1st function defines project performance
    def project_performance():
        """function to update performance log"""
        global data_crawl
        global count_row
        platform = vendor_options.value
        work_order = work_order_box.value
        job_address = service_address_box.value
        arrival_city_name = service_city_box.value
        state_name = service_state.value
        job_zip_code = city_zipcode_box.value
        data = [[platform, timestamp, work_order, job_address, arrival_city_name, state_name, job_zip_code]]
        df = pd.DataFrame(data, columns=['PLATFORM', 'DATE', 'WORK ORDER', 'ADDRESS', 'CITY', 'STATE', 'ZIP'])
        if not os.path.isfile(contractor_log):
            df.to_csv(contractor_log, header='column_names')
        else:  # else it exists so append without writing the header
            df.to_csv(contractor_log, mode='a', header=False)
        window1.info("Log Submission", "Work Order {0} has been submitted".format(work_order_box.value))

    # closed current window
    def close_window_1():
        """Close window 1 function"""
        window1.hide()
    """Open Service Log Window function"""
    window1 = Window(app, title="Update Service Log")
    Box(window1, align="left", )
    title_box = Box(window1, width="fill", align="top", border=True)
    Text(title_box, text="Update Performance Log")
    window1_logo = Picture(window1, image="{0}".format(bwit_logo))
    content_box = Box(window1, align="top", width="fill")
    form_box = Box(content_box, layout="grid", width="fill", align="left", border=True)
    Text(form_box, grid=[1, 0], text="", align="left")
    work_order_label = Text(form_box, grid=[0, 2], text="WORK ORDER", align="left")
    work_order_box = TextBox(form_box, grid=[1, 2], text="enter WO#", width="fill")

    service_address_label = Text(form_box, grid=[0, 3], text="SERVICE ADDRESS", align="left")
    service_address_box = TextBox(form_box, grid=[1, 3], text="enter address", width="fill")

    service_city_label = Text(form_box, grid=[0, 4], text="SERVICE CITY", align="left")
    service_city_box = TextBox(form_box, grid=[1, 4], text="enter city", width="fill")

    city_zipcode_label = Text(form_box, grid=[0, 5], text="POSTAL CODE", align="left")
    city_zipcode_box = TextBox(form_box, grid=[1, 5], text="enter zipcode", width="fill")
    combo_box = Box(window1, width="fill")
    service_state = Combo(combo_box, options=["OR", "WA"], align="left")
    service_state_label = Text(combo_box, text="Select State", align="left")
    vendor_options = Combo(combo_box, options=["Atlas", "BWIT", "CCS", "Field_Nation", "TechLink", "Work_Market"],
                           align="right")
    vendor_options_label = Text(combo_box, text="Select Vendor", align="right")
    buttons_box = Box(window1, width="fill", align="bottom")
    Picture(window1, image="{0}".format(art_logo))
    Text(buttons_box, text="")
    cancel = PushButton(buttons_box, text="Cancel", align="right", command=close_window_1)
    ok = PushButton(buttons_box, text="Submit", align="right", command=project_performance)

    window1.show(wait=True)


# Function use to Open the Mileage Calculation window
def open_window_2():
    # Function used to perform mileage calculation
    def calculate_miles():
        """function to calculate mileage and travel cost"""
        gallons = 33
        mpg = 15
        fill_up = int(gallons) * float(gasoline.value)
        full_tank = int(mpg) * int(gallons)
        tanks = int(miles.value) / int(full_tank)
        fuel_per_trip = int(miles.value) / int(gallons)
        fuel_cost = round(fuel_per_trip, 2) * float(gasoline.value)
        total_cost = round(fill_up * tanks)
        hours = int(miles.value) / int(speed.value)
        minutes = round(hours, 2) * 60
        days = int(hours) / 24
        pay_for_travel = int(travel_rate.value) * int(hours)
        mileage_window = Window(app, title="Compensation Results")
        mileage_window_logo = Picture(mileage_window, image="{0}".format(bwit_logo), align="top")

        if int(miles.value) >= 40:
            mileage_window.show(wait=True)
            Text(mileage_window,
                 text="This Project in {0} is {1:.1f} hours away".format(travel_destination.value, hours))
            Text(mileage_window, text="")
            mileage_box = Box(mileage_window, align="top", width="fill")
            fuel_form_box = Box(mileage_box, layout="grid", width="fill", align="left", border=True)

            Text(fuel_form_box, grid=[0, 0], text="TRAVEL COMPENSATION:", align="left")
            Text(fuel_form_box, grid=[1, 0], text="${0:.2f}".format(pay_for_travel), align="left")

            Text(fuel_form_box, grid=[0, 1], text="FILL UP COST ", align="left")
            Text(fuel_form_box, grid=[1, 1], text="${0:.2f}".format(fill_up), align="left")

            Text(fuel_form_box, grid=[0, 2], text="GALLONS OF FUEL", align="left")
            Text(fuel_form_box, grid=[1, 2], text="{0:.2f}".format(fuel_cost), align="left")

            Text(fuel_form_box, grid=[0, 3], text="TRAVEL DISTANCE", align="left")
            Text(fuel_form_box, grid=[1, 3], text="{0:.2f} miles on one tank".format(full_tank), align="left")

            Text(fuel_form_box, grid=[0, 4], text="ONEWAY TRIP", align="left")
            Text(fuel_form_box, grid=[1, 4], text="{0:.1f} tanks of fuel".format(tanks), align="left")

            Text(fuel_form_box, grid=[0, 5], text="ROUND TRIP", align="left")
            Text(fuel_form_box, grid=[1, 5], text="{0:.1f} tanks of fuel".format(tanks * 2), align="left")

            Text(fuel_form_box, grid=[0, 6], text="ONEWAY COST", align="left")
            Text(fuel_form_box, grid=[1, 6], text="${0:.2f}".format(total_cost), align="left")

            Text(fuel_form_box, grid=[0, 7], text="ROUND TRIP COST", align="left")
            Text(fuel_form_box, grid=[1, 7], text="${0:.2f}".format(total_cost * 2), align="left")

            Text(fuel_form_box, grid=[0, 8], text="MINUTES", align="left")
            Text(fuel_form_box, grid=[1, 8], text="{0:.1f}".format(minutes), align="left")

            Text(fuel_form_box, grid=[0, 9], text="HOURS", align="left")
            Text(fuel_form_box, grid=[1, 9], text="{0:.1f}".format(hours), align="left")

            Text(fuel_form_box, grid=[0, 10], text="DAYS", align="left")
            Text(fuel_form_box, grid=[1, 10], text="{0:.1f}".format(days), align="left")
            PushButton(mileage_window, text="Close Window", command=mileage_window.hide)
        else:
            mileage_window.info("No Compensation",
                                "The Project in {0} is in your Travel Zone".format(travel_destination.value))

    # Functions used to close current window 2
    def close_window_2():
        """Close window 1 function"""
        window2.hide()
    """Open Compensation window function"""
    # Window 2 Mileage Compensation
    window2 = Window(app, title="Mileage Compensation")
    title_box = Box(window2, width="fill", align="top", border=True)
    Text(title_box, text="Calculate Mileage")
    window2_logo = Picture(window2, image="{0}".format(bwit_logo))
    content_box_2 = Box(window2, align="top", width="fill")
    form_box = Box(content_box_2, layout="grid", width="fill", align="left", border=True)
    Text(form_box, grid=[1, 0], text="", align="left")
    travel_destination_label = Text(form_box, grid=[0, 2], text="DESTINATION CITY", align="left")
    travel_destination = TextBox(form_box, grid=[1, 2], text="enter city", width="fill")

    miles_label = Text(form_box, grid=[0, 3], text="MILES TO PROJECT", align="left")
    miles = TextBox(form_box, grid=[1, 3], text="enter miles", width="fill")

    gasoline_label = Text(form_box, grid=[0, 4], text="PRICE OF GAS", align="left")
    gasoline = TextBox(form_box, grid=[1, 4], text="enter fuel price", width="fill")

    speed_label = Text(form_box, grid=[0, 5], text="TRAVEL SPEED", align="left")
    speed = TextBox(form_box, grid=[1, 5], text="enter speed", width="fill")

    travel_rate_label = Text(form_box, grid=[0, 6], text="TRAVEL RATE", align="left")
    travel_rate = TextBox(form_box, grid=[1, 6], text="enter hourly rate", width="fill")

    travel_buttons_box = Box(window2, width="fill", align="bottom")
    Picture(window2, image="{0}".format(art_logo))
    Text(travel_buttons_box, text="")
    mileage_cancel = PushButton(travel_buttons_box, text="Cancel", align="right", command=close_window_2)
    mileage_calculate = PushButton(travel_buttons_box, text="Submit", align="right", command=calculate_miles)
    window2.show(wait=True)


# Function used to Show Performance Graphs
def open_window_3():
    def close_window_3():
        """Open window 3 function"""
        window3.hide()

    """Open Performance Graphs window function"""
    # Window 4 Display Charts
    window3 = Window(app, title="View Graphs")
    title_box = Box(window3, width="fill", align="top", border=True)
    Text(title_box, text="View Performance Graphs")
    Picture(window3, image="{0}".format(bwit_logo))
    Text(window3, text="Choose One")
    PushButton(window3, command=monthly_performance, text="Performance by Month", width=20, height=1)
    PushButton(window3, command=city_performance, text="Performance by City", width=20, height=1)
    PushButton(window3, command=state_performance, text="Performance by State", width=20, height=1)
    PushButton(window3, command=vendor_performance, text="Performance by Vendor", width=20, height=1)
    PushButton(window3, command=yearly_performance, text="Performance by Year", width=20, height=1)
    exit_buttons_box = Box(window3, width="fill", align="bottom")
    Picture(window3, image="{0}".format(art_logo))
    PushButton(exit_buttons_box, command=close_window_3, text="Close", align="right", width=20)
    window3.show(wait=True)


def open_window_4():

    def close_tracker_app():
        """Open window 3 function"""
        track_app.hide()

    def address_tracker():
        geo_locator = Nominatim(user_agent="Address_Locator")

        start_address = start_point_add.value
        end_address = end_point_add.value
        s = geo_locator.geocode(start_address)
        e = geo_locator.geocode(end_address)

        s_lat = s.latitude
        s_long = s.longitude
        e_lat = e.latitude
        e_long = e.longitude

        # input variable for longitude and latitude coordinates
        starting_latitude = radians(float(s_lat))
        starting_longitude = radians(float(s_long))
        ending_latitude = radians(float(e_lat))
        ending_longitude = radians(float(e_long))

        # Calculate the distance between to positioning points longitude/latitude in km
        dist = 6371.01 * acos(sin(starting_latitude) * sin(ending_latitude)
                              + cos(starting_latitude) * cos(ending_latitude) * cos(
            starting_longitude - ending_longitude))

        # converts distance in km to miles
        air_miles = dist / 1.609344
        fig = Figure(width=550, height=350)
        ip_map = folium.Map(location=[s_lat, s_long], default_zoom_start=10)
        fig.add_child(ip_map)  # Mapping Layers
        folium.TileLayer('Stamen Terrain').add_to(ip_map)
        folium.TileLayer('Stamen Toner').add_to(ip_map)
        folium.TileLayer('Stamen Water Color').add_to(ip_map)
        folium.TileLayer('cartodbpositron').add_to(ip_map)
        folium.TileLayer('cartodbdark_matter').add_to(ip_map)
        folium.LayerControl().add_to(ip_map)
        folium.Marker(  # Starting Point Marker
            location=[s_lat, s_long], popup=[start_address, round(air_miles), '<b>air miles<b>'],
            tooltip="Start Address",
        ).add_to(ip_map)

        folium.Marker(  # Starting Point Marker
            location=[e_lat, e_long], popup=[end_address, round(air_miles), 'air miles'], tooltip="End Address",
        ).add_to(ip_map)

        # added lat long to route
        route_lats_longs = [[s_lat, s_long],  # Start Location
                            [e_lat, e_long]]  # End Location
        # Plotting ant-route
        plugins.AntPath(route_lats_longs).add_to(ip_map)

        ip_map.save(html_file, 'wb')
        webbrowser.open_new_tab(html_file)
    # Main App Window BWIT APP
    track_app = Window(app, title="BWIT Address Tracker")
    Picture(track_app, image="{0}".format(bwit_logo))
    title_box = Box(track_app, width="fill", align="top", border=True)
    Text(title_box, text="Locate Address")
    Text(track_app, text="")
    form_box = Box(title_box, layout="grid", width="fill", align="left", border=True)
    start_point_label = Text(form_box, grid=[0, 2], text="Starting Address", align="right")
    start_point_add = TextBox(form_box, grid=[2, 2], text="Starting Address", width="fill")
    Text(track_app, text="")
    Text(track_app, text="")
    end_point_label = Text(form_box, grid=[0, 3], text="Ending Address", align="right")
    end_point_add = TextBox(form_box, grid=[2, 3], text="Destination Address", width="fill")
    create_map = PushButton(track_app, command=address_tracker, text="Create Map", width=20, height=1)
    exit_buttons_box = Box(track_app, width="fill", align="bottom")
    Picture(track_app, image="{0}".format(art_logo))
    Text(exit_buttons_box, text="")
    PushButton(exit_buttons_box, command=close_tracker_app, text="Quit Program", align="right", width=20)
    track_app.show(wait=True)


# Function used to close main App Window
def exit_button():
    """Function to exit application"""
    exit()


# App -----------------------------------------------------------------------------------------------------------------
# Main App Window BWIT APP
app = App(title="T.L.R.C App")
company_logo = Picture(app, image="{0}".format(bwit_logo))
Text(app, text="")
update_platform = PushButton(app, command=open_window_1, text="Update Service Log", width=20, height=1)
Text(app, text="")
mile_comp = PushButton(app, command=open_window_2, text="Mileage Compensation", width=20, height=1)
Text(app, text="")
weather_report = PushButton(app, command=open_window_3, text="Display Charts", width=20, height=1)
Text(app, text="")
address_track = PushButton(app, command=open_window_4, text="Address Locator", width=20, height=1)
Text(app, text="")
quit_app = PushButton(app, command=exit_button, text="Quit Program", width=20)

# Displays Window of your main Application
app.display()
